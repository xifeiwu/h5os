adb remount &&
adb push ./keylayout/gpio-keys.kl /system/usr/keylayout/ &&
adb push ./keylayout/matrix-keypad.kl /system/usr/keylayout/ &&
adb push ./keylayout/qpnp_pon.kl /system/usr/keylayout/ &&
adb push ./volume.cfg /system/etc/ &&
adb reboot
